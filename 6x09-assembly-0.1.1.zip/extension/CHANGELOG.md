# Change Log
All notable changes to the "vscode-6x09-assembly" extension will be documented in this file.

## [0.1.1]
- Initial release
- Syntax Highlighting, bracket matching, bracket autoclosing, brack surronding, comment toggling, autoindentation and folding